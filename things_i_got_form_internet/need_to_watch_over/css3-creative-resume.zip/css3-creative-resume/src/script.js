/*
VIEW IN FULL MODE :: IT LOOKS MUCH BETTER WHEN VIEWED IN FULL MODE


my intention was to use lettering.js to create the word* classes, but for some reason it didn't generate them even after including the script and calling it, it works locally but not on codepen*/

/*

Librarian Image is from Dribbble: http://dribbble.com/shots/271458-Librarian 
by talented "Artua"

*/